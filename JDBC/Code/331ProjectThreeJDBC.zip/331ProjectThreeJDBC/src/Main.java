import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {

        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();


        try {

            // 1. Creating a class for DB localhost
            SQLServerDataSource ds = new SQLServerDataSource();
            ds.setUser("sa");
            ds.setPassword("mt@123456789");
            ds.setServerName("localhost");
            ds.setPortNumber(1433);
            ds.setDatabaseName("QueensCollegeSchedulSpring2019");

            Connection cn = ds.getConnection();

            // 2. Create Statement
            Statement statement = cn.createStatement();


            statement.executeUpdate(" EXEC [Project3].[BuildQueensCollegeScheduleSpring2019Database]");

            ResultSet resultSet = statement.executeQuery("SELECT * FROM [Process].[WorkFlowSteps]");

            System.out.println(
                    "WorkFLowStepKey " +
                            " WorkFlowStepDescription " +
                            " WorkFlowStepTableRowCount " +
                            " StartingDateTime " +
                            " EndingDateTime " +
                            " ClassTime " +
                            " AuthorizedUserId");
            while (resultSet.next()) {
                System.out.print(
                        resultSet.getString("WorkFlowStepKey") + " " +
                                resultSet.getString("WorkFlowStepDescription") + " " +
                                resultSet.getString("WorkFlowStepTableRowCount") + " " +
                                resultSet.getString("StartingDateTime") + " " +
                                resultSet.getString("EndingDateTime") + " " +
                                resultSet.getString("ClassTime") + " " +
                                resultSet.getString("AuthorizedUserId") + " \n"


                );

            }


            System.out.println();
            System.out.println();
            System.out.println("------------------------------------ QUESTION 1 ------------------------------------------");


            System.out.println("-- 1. Show all instructors who are teaching in classes in multiple departments");
            System.out.println();
            System.out.println("PROPOSITION: There exists 0, 1, or many instructors who are teaching in several departments");

            System.out.println(
                    "InstructorFullName " + " DepartmentName");
            resultSet = statement.executeQuery("SELECT" +
                    "    DISTINCT" +
                    "    InstructorFullName," +
                    "    DepartmentName " +
                    "FROM [Queens-College].[Instructor] AS I\n" +
                    "    INNER JOIN [Queens-College].[DepartmentInstructor] AS DI\n" +
                    "        ON I.InstructorID = DI.[InstructorKey]\n" +
                    "    INNER JOIN [Queens-College].[Department] AS D\n" +
                    "        ON DI.[DepartmentKey] = D.DepartmentID\n" +
                    "    INNER JOIN [Queens-College].[Class] AS C\n" +
                    "        ON DI.InstructorKey = I.InstructorID\n" +
                    "ORDER BY InstructorFullName, DepartmentName;");

            while (resultSet.next()) {
                System.out.println(resultSet.getString("InstructorFullName") + " --- "+ resultSet.getString("DepartmentName"));
            }


            System.out.println();
            System.out.println("---------------------------------------------------------");







            System.out.println("------------------------------------ QUESTION 2 ------------------------------------------");

            System.out.println();
            System.out.println("2. How many instructors are in each department?");
            System.out.println();
            System.out.println("PROPOSITION: There exists many instructors in each department");


            System.out.println("InstructorCount " +" --- " + " DepartmentName" );

            resultSet = statement.executeQuery("" +
                    "SELECT\n" +
                    "    COUNT(InstructorFullName) AS InstructorCount,\n" +
                    "    DepartmentName\n" +
                    "FROM [Queens-College].[Instructor] AS I\n" +
                    "    INNER JOIN [Queens-College].[DepartmentInstructor] AS DI\n" +
                    "        ON I.InstructorID = DI.[InstructorKey]\n" +
                    "    INNER JOIN [Queens-College].[Department] AS D\n" +
                    "        ON DI.[DepartmentKey] = D.DepartmentID\n" +
                    "GROUP BY DepartmentName;");

            while (resultSet.next()) {
                System.out.println(
                        resultSet.getString("InstructorCount") + " --- " +
                                resultSet.getString("DepartmentName")
                );
            }


            System.out.println();
            System.out.println("--------------------------------------------------------------------");




            System.out.println("------------------------------------ QUESTION 3 ------------------------------------------");

            System.out.println();
            System.out.println("3. How many classes that are being taught that semester grouped by course and aggregating the total enrollment, " +
                    "total class limit and the percentage of enrollment.");
            System.out.println();
            System.out.println("PROPOSITION: There exists many classes with an enrollment to limit ratio that may be less than 100% or greater than 100%");


            System.out.println("CourseName    TotalNumberOfPeopleEnrolled    TotalClassLimit");
            resultSet = statement.executeQuery("" +
                    "SELECT\n" +
                    "    CourseName,\n" +
                    "    SUM(Enrolled) AS [Total Number Of People Enrolled],\n" +
                    "    SUM([Limit]) AS [Total Class Limit],\n" +
                    "    CASE WHEN \n" +
                    "        SUM([Limit]) = 0 THEN CONCAT(0, '%')\n" +
                    "        ELSE\n" +
                    "            CONCAT(CAST((SUM([Enrolled]) * 100.00) / SUM([Limit])  AS DECIMAL(6,2)), '%')\n" +
                    "    END AS PercentOfEnrollment \n" +
                    "FROM [Queens-College].[Class] AS C\n" +
                    "    INNER JOIN [Queens-College].[Course] AS Course\n" +
                    "        ON C.CourseKey = Course.CourseID\n" +
                    "GROUP BY CourseName;");

            while (resultSet.next()) {
                System.out.println(resultSet.getString("CourseName") + " --- " +
                        resultSet.getString("Total Number Of People Enrolled") + " --- "+
                        resultSet.getString("Total Class Limit") + " --- " +
                        resultSet.getString("PercentOfEnrollment"));
            }



        System.out.println("--------------------------------------------------------------------");




        System.out.println("------------------------------------ QUESTION 4 ------------------------------------------");

        System.out.println();
        System.out.println("4 Which class had the most students enrolled?");
        System.out.println();
        System.out.println("PROPOSITION: There exists a class with the most enrolled students");

            System.out.println("CourseName   TotalNumberOfPeopleEnrolled");
        System.out.println();
        resultSet = statement.executeQuery("" +
                "SELECT TOP 1\n" +
                "    CourseName,\n" +
                "    SUM(Enrolled) AS [Total Number Of People Enrolled]\n" +
                "FROM [Queens-College].[Class] AS C\n" +
                "    INNER JOIN [Queens-College].[Course] AS Course\n" +
                "        ON C.CourseKey = Course.CourseID\n" +
                "GROUP BY CourseName\n" +
                "ORDER BY [Total Number Of People Enrolled] DESC;");

        while (resultSet.next()) {
            System.out.println(resultSet.getString("CourseName") + " --- "+
                    resultSet.getString("Total Number Of People Enrolled"));
        }



            System.out.println("--------------------------------------------------------------------");




            System.out.println("------------------------------------ QUESTION 5 ------------------------------------------");

            System.out.println();
            System.out.println("5. What was the 5th most common time slot for classes?");
            System.out.println();
            System.out.println("PROPOSITION: There exists a time slot that is the 5th most common.");

            System.out.println("ClassStartingTime    TotalClassWithSameStartingTime");
            System.out.println();
            resultSet = statement.executeQuery("" +
                    "SELECT\n" +
                    "    ClassStartingTime,\n" +
                    "    COUNT(ClassStartingTime) AS [Total Classes With Same Starting Time]\n" +
                    "FROM [Queens-College].[TimeSlot] AS TS\n" +
                    "    INNER JOIN [Queens-College].[Class] AS C\n" +
                    "        ON TS.TimeSlotID = C.TimeSlotKey\n" +
                    "GROUP BY ClassStartingTime\n" +
                    "ORDER BY [Total Classes With Same Starting Time] DESC\n" +
                    "OFFSET 4 ROWS FETCH NEXT 1 ROWS ONLY;");

            while (resultSet.next()) {
                System.out.println(resultSet.getString("ClassStartingTime") + " --- "+
                        resultSet.getString("Total Classes With Same Starting Time"));
            }


            System.out.println("--------------------------------------------------------------------");









            System.out.println("------------------------------------ QUESTION 6 ------------------------------------------");

            System.out.println();
            System.out.println("6. Display the amount of classes taught by each professor per department. Grouped by InstructorFullName and DepartmentName");
            System.out.println();
            System.out.println("PROPOSITION: There exists Instructors in several departments that have taught various classes.");

            System.out.println("InstructorFullName   DepartmentName   NumberOfClasseesTaught");
            System.out.println();
            resultSet = statement.executeQuery("" +
                    "SELECT\n" +
                    "    InstructorFullName,\n" +
                    "    DepartmentName,\n" +
                    "    COUNT(InstructorFullName) AS [Number Of Classes Taught]\n" +
                    "FROM [Queens-College].[Instructor] AS I\n" +
                    "    INNER JOIN [Queens-College].[Class] AS C\n" +
                    "        ON I.InstructorID = C.InstructorKey\n" +
                    "    INNER JOIN [Queens-College].[DepartmentInstructor] AS DI\n" +
                    "        ON DI.InstructorKey = I.InstructorID\n" +
                    "    INNER JOIN [Queens-College].[Department] AS D\n" +
                    "        ON D.DepartmentID = DI.DepartmentKey \n" +
                    "WHERE LEN(InstructorFullName) > 1\n" +
                    "GROUP BY InstructorFullName, DepartmentName ORDER BY InstructorFullName;");

            while (resultSet.next()) {
                System.out.println(resultSet.getString("InstructorFullName") + " --- "+
                        resultSet.getString("DepartmentName") + " --- "+
                        resultSet.getString("Number Of Classes Taught"));
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
